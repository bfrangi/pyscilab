# pyscilab
Package including useful methods to process data from laboratory experiments
